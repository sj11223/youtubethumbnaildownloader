# [YouTube Thumbnail Downloader](https://harsh98trivedi.github.io/YouTube-Thumbnail-Downloader) :fire:

Free, Clean & Simple **YouTube Thumbnail Downloader** for you. :slightly_smiling_face: <br>
Download **YouTube video thumbnails** with ease.<br>
This project was initially hosted on [**Firebase**](https://yt-thumbnail-downloader.firebaseapp.com), but then I thought of uploading it to **GitHub**. :rocket:

---

![YouTube Thumbnail Downloader](https://raw.github.com/harsh98trivedi/YouTube-Thumbnail-Downloader/master/images/meta.jpg)

#### Libraries Used

---

* Bootstrap - http://getbootstrap.com/
* jQuery - http://jquery.com/

> License: [GNU General Public License v3.0](https://github.com/harsh98trivedi/YouTube-Thumbnail-Downloader/blob/master/LICENSE.md)

![YouTube Thumbnail Downloader](https://img.shields.io/badge/YouTube-Thumbnail%20Downloader-green.svg)